interface ICommandResponses {
    /**
     * The command completion code.
     * @type{string}
     */
    completionCode: string;
    /**
     * The command reason code.
     * @type{string}
     */
    reasonCode: string;
    /**
     * The command response text.
     * @type{string[]}
     */
    text: string[];
}
/**
 * The IMQResponse API response.
 * @export
 */
export interface IMQResponse {
    /**
     * The command response text.
     * @type{string[]}
     */
    commandResponse: ICommandResponses[];
    /**
     * The completion code object.
     * @type{string}
     */
    overallCompletionCode: string;
    /**
     * The reaason code object.
     * @type{string}
     */
    overallReasonCode: string;
}
export {};
