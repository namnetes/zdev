import { Session } from "@zowe/imperative";
import { IMQResponse } from "./doc/IMQResponse";
/**
 * Class of utility file APIs for usage within the CLI and programmatically from node scripts.
 * @export
 * @class Command
 */
export default class MQSCCommand {
    /**
     * Runs the specified MQSC command on the specified queue manager.
     * @param {Session}  session      - MQ connection info
     * @param {string} queueMgrName - The Queue manager to apply command to
     * @param {string} command - The command to be run.
     * @param {boolean} csrfHeader - Set the CSRF protection header, default is true
     * @throws ImperativeError
     * @memberof Command
     */
    static qmgrAction(session: Session, queueMgrName: string, thecommand: string, csrfHeader?: boolean): Promise<IMQResponse>;
}
