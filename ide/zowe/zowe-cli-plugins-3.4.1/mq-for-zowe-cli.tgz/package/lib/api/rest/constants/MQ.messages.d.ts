import { IMessageDefinition } from "@zowe/imperative";
/**
 * Messages to be used as command responses for different scenarios
 * @type {object.<string, IMessageDefinition>}
 * @memberOf MQMessages
 */
export declare const MQMessages: {
    [key: string]: IMessageDefinition;
};
