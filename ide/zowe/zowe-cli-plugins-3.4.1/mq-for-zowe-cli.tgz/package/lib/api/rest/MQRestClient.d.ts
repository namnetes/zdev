import { IImperativeError, RestClient } from "@zowe/imperative";
/**
 * Wrapper for invoke MQ API through the RestClient to perform common error
 * handling and checking and resolve promises according to generic types
 * @export
 * @class MQRestClient
 * @extends {RestClient}
 */
export declare class MQRestClient extends RestClient {
    /**
     * Internal logger
     */
    private static mLogger;
    /**
     * Use the Brightside logger instead of the imperative logger
     * @return {Logger}
     */
    private static get log();
    /**
     * Process an error encountered in the rest client
     * @param {IImperativeError} original - the original error automatically built by the abstract rest client
     * @returns {IImperativeError} - the processed error with details added
     * @memberof MQRestClient
     */
    protected processError(original: IImperativeError): IImperativeError;
}
