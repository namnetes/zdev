/**
 * Constants to be used by the API
 * @memberOf MQConstants
 */
export declare const MQConstants: {
    [key: string]: any;
};
