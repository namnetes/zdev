import { ICommandArguments, ICommandOptionDefinition, IHandlerParameters, IProfile, Session } from "@zowe/imperative";
/**
 * Utility Methods for Zowe
 * @export
 */
export declare class MqSessionUtils {
    static MQ_CONNECTION_OPTION_GROUP: string;
    /**
     *
     * Option used in profile creation and commands for hostname for MQ
     */
    static MQ_OPTION_HOST: ICommandOptionDefinition;
    /**
     * Option used in profile creation and commands for port for MQ
     */
    static MQ_OPTION_PORT: ICommandOptionDefinition;
    /**
     * Option used in profile creation and commands for username / ID  for MQ
     */
    static MQ_OPTION_USER: ICommandOptionDefinition;
    /**
     * Option used in profile creation and commands for password/passphrase for MQ
     */
    static MQ_OPTION_PASSWORD: ICommandOptionDefinition;
    /**
     * Option used in profile creation and commands for rejectUnauthorized setting for connecting to FMP
     */
    static MQ_OPTION_REJECT_UNAUTHORIZED: ICommandOptionDefinition;
    /**
     * Option used in profile creation and commands for protocol for MQ
     */
    static MQ_OPTION_PROTOCOL: ICommandOptionDefinition;
    /**
     * Options related to connecting to MQ
     * These options can be filled in if the user creates a profile
     */
    static MQ_CONNECTION_OPTIONS: ICommandOptionDefinition[];
    static createSessCfgFromArgs(args: ICommandArguments, doPrompting?: boolean, handlerParams?: IHandlerParameters): Promise<Session>;
    /**
     * Given a MQ profile, create a REST Client Session.
     * @static
     * @param {IProfile} profile - The MQ profile contents
     * @returns {Session} - A session for usage in the MQ REST Client
     */
    static createBasicMqSession(profile: IProfile): Session;
    /**
     * Given a MQ profile, create a REST Client Session.
     * @static
     * @param {IProfile} profile - The MQ profile contents
     * @returns {Session} - A session for usage in the MQ REST Client
     */
    static createBasicMqSessionFromArguments(args: ICommandArguments): Session;
    /**
     * Internal logger
     */
    private static mLogger;
    /**
     * Use the Brightside logger instead of the imperative logger
     * @return {Logger}
     */
    private static get log();
}
