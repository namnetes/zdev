import { ICommandDefinition } from "@zowe/imperative";
export declare const MQSCCommandDefinition: ICommandDefinition;
