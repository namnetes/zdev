import { ICommandDefinition } from "@zowe/imperative";
declare const CommandDefinition: ICommandDefinition;
export = CommandDefinition;
