import { IHandlerParameters, Session } from "@zowe/imperative";
import { IMQResponse } from "../../../api/doc/IMQResponse";
import MqBaseHandler from "../../MQBaseHandler";
/**
 * Command handler for MQSC script commands
 * @export
 * @class MQSCCommandHandler
 * @implements {ICommandHandler}
 */
export default class MQSCCommandHandler extends MqBaseHandler {
    /**
     * Process the MQSC script command.
     * @param {IHandlerParameters} params
     * @returns {Promise<void>}
     * @memberof MQSCCommandHandler
     */
    processWithSession(params: IHandlerParameters, session: Session): Promise<IMQResponse>;
}
