declare const _default: {
    COMMAND: {
        DESCRIPTION: string;
        SUMMARY: string;
        MQSC: {
            DESCRIPTION: string;
            POSITIONALS: {
                THECOMMAND: string;
                QUEUEMANAGER: string;
                CSRF: string;
            };
            EXAMPLES: {
                EX1: string;
            };
        };
    };
};
export default _default;
