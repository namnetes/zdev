import { ICommandHandler, IHandlerParameters, Session } from "@zowe/imperative";
import { IMQResponse } from "../api/doc/IMQResponse";
/**
 * This class is used by the various mq handlers as the base class for their implementation.
 * All handlers should extend this class whenever possible
 */
export default abstract class MqBaseHandler implements ICommandHandler {
    /**
     * This will grab the mq profile and create a session before calling the subclass
     * {@link MqBaseHandler#processWithSession} method.
     *
     * @param {IHandlerParameters} commandParameters Command parameters sent by imperative.
     *
     * @returns {Promise<IMQResponse>}
     */
    process(commandParameters: IHandlerParameters): Promise<void>;
    /**
     * This is called by the {@link MqBaseHandler#process} after it creates a session. Should
     * be used so that every class does not have to instantiate the session object.
     *
     * @param {IHandlerParameters} commandParameters Command parameters sent to the handler.
     * @param {Session} session The session object generated from the mq profile.
     *
     * @returns {Promise<IMQResponse>} The response from the underlying mq api call.
     */
    abstract processWithSession(commandParameters: IHandlerParameters, session: Session): Promise<IMQResponse>;
}
