export declare class Utilities {
    /**
     * Check to ensure filename only contains valid characters
     * @param {fileName} string - filename to be evaluated
     * @returns {Promise<boolean>} - promise that resolves to true if filename contains valid characters
     * @memberof Utilities
     */
    static isValidFileName(fileName: string): boolean;
}
