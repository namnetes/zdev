import { FTPBaseHandler } from "../../../FTPBase.Handler";
import { IFTPHandlerParams } from "../../../IFTPHandlerParams";
/**
 * "zos-ftp view spool-by-id" command handler. Outputs a single spool DD contents.
 */
export default class SpoolFileByIdHandler extends FTPBaseHandler {
    processFTP(params: IFTPHandlerParams): Promise<void>;
}
