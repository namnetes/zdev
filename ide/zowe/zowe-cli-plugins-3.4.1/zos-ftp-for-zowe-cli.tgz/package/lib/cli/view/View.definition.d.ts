import { ICommandDefinition } from "@zowe/imperative";
declare const ViewDefinition: ICommandDefinition;
export = ViewDefinition;
