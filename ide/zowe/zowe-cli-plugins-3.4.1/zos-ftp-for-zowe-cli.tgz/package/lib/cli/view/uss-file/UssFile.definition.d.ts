import { ICommandDefinition } from "@zowe/imperative";
export declare const ViewUssFileDefinition: ICommandDefinition;
