import { ICommandDefinition } from "@zowe/imperative";
export declare const ViewSpoolFileByIdDefinition: ICommandDefinition;
