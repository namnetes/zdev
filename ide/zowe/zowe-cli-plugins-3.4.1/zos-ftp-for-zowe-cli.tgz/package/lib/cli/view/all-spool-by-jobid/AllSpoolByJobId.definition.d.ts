import { ICommandDefinition } from "@zowe/imperative";
export declare const ViewAllSpoolByJobidDefinition: ICommandDefinition;
