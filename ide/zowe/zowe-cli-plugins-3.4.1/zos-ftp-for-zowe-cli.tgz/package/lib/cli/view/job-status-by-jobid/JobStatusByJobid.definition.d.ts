import { ICommandDefinition } from "@zowe/imperative";
export declare const ViewJobStatusByJobidDefinition: ICommandDefinition;
