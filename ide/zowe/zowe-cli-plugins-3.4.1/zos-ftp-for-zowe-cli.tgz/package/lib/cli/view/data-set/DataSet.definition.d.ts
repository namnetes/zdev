import { ICommandDefinition } from "@zowe/imperative";
export declare const ViewDataSetDefinition: ICommandDefinition;
