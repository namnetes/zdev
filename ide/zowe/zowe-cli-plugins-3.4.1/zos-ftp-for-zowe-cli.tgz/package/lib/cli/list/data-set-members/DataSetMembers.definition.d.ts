import { ICommandDefinition } from "@zowe/imperative";
export declare const ListDataSetMembersDefinition: ICommandDefinition;
