import { IFTPHandlerParams } from "../../../IFTPHandlerParams";
import { FTPBaseHandler } from "../../../FTPBase.Handler";
export default class ListDataSetsHandler extends FTPBaseHandler {
    processFTP(params: IFTPHandlerParams): Promise<void>;
}
