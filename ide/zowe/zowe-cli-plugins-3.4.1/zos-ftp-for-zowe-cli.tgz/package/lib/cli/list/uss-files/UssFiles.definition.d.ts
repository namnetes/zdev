import { ICommandDefinition } from "@zowe/imperative";
export declare const ListUssFilesDefinition: ICommandDefinition;
