import { FTPBaseHandler } from "../../../FTPBase.Handler";
import { IFTPHandlerParams } from "../../../IFTPHandlerParams";
/**
 * "zos-ftp list spool-files" command handler. Outputs a table of spool files.
 */
export default class ListSpoolFilesByJobidHandler extends FTPBaseHandler {
    processFTP(params: IFTPHandlerParams): Promise<void>;
}
