import { ICommandDefinition } from "@zowe/imperative";
export declare const ListDataSetDefinition: ICommandDefinition;
