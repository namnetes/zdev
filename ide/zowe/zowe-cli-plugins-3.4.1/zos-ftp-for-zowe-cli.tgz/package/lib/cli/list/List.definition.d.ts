import { ICommandDefinition } from "@zowe/imperative";
declare const ListDefinition: ICommandDefinition;
export = ListDefinition;
