import { ICommandDefinition } from "@zowe/imperative";
declare const DownloadDefinition: ICommandDefinition;
export = DownloadDefinition;
