import { ICommandDefinition } from "@zowe/imperative";
export declare const DownloadDataSetDefinition: ICommandDefinition;
