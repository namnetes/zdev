import { ICommandDefinition } from "@zowe/imperative";
export declare const DownloadAllSpoolByJobidDefinition: ICommandDefinition;
