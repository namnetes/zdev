import { ICommandDefinition } from "@zowe/imperative";
export declare const RenameUssFileDefinition: ICommandDefinition;
