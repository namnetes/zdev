import { ICommandDefinition } from "@zowe/imperative";
declare const RenameDefinition: ICommandDefinition;
export = RenameDefinition;
