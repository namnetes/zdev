import { ICommandDefinition } from "@zowe/imperative";
export declare const RenameDataSetDefinition: ICommandDefinition;
