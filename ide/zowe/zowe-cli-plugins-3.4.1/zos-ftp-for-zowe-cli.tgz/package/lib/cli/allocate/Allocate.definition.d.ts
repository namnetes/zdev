import { ICommandDefinition } from "@zowe/imperative";
declare const AllocateDefinition: ICommandDefinition;
export = AllocateDefinition;
