import { ICommandDefinition } from "@zowe/imperative";
export declare const AllocateDataSetDefinition: ICommandDefinition;
