import { ICommandDefinition } from "@zowe/imperative";
export declare const SubmitDataSetDefinition: ICommandDefinition;
