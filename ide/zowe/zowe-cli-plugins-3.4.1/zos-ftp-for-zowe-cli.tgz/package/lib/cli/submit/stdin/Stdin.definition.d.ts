import { ICommandDefinition } from "@zowe/imperative";
export declare const SubmitStdinDefinition: ICommandDefinition;
