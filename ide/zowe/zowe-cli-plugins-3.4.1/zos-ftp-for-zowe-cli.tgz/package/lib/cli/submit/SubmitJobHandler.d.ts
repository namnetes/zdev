import { FTPBaseHandler } from "../../FTPBase.Handler";
import { IFTPHandlerParams } from "../../IFTPHandlerParams";
export declare abstract class SubmitJobHandler extends FTPBaseHandler {
    submitJCL(jcl: string, params: IFTPHandlerParams): Promise<void>;
}
