import { ICommandDefinition } from "@zowe/imperative";
declare const SubmitDefinition: ICommandDefinition;
export = SubmitDefinition;
