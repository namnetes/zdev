import { IFTPHandlerParams } from "../../../IFTPHandlerParams";
import { SubmitJobHandler } from "../SubmitJobHandler";
export default class SubmitJobFromLocalFileHandler extends SubmitJobHandler {
    processFTP(params: IFTPHandlerParams): Promise<void>;
}
