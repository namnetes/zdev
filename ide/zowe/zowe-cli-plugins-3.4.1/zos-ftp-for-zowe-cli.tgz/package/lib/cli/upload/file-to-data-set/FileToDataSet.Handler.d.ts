import { IFTPHandlerParams } from "../../../IFTPHandlerParams";
import { FTPBaseHandler } from "../../../FTPBase.Handler";
export default class UploadFileToDataSetHandler extends FTPBaseHandler {
    processFTP(params: IFTPHandlerParams): Promise<void>;
}
