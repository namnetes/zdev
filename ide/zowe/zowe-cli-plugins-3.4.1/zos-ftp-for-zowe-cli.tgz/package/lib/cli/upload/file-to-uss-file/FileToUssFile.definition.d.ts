import { ICommandDefinition } from "@zowe/imperative";
export declare const UploadFileToUssFileDefinition: ICommandDefinition;
