import { ICommandDefinition } from "@zowe/imperative";
export declare const UploadStdinToUssFileDefinition: ICommandDefinition;
