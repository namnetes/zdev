import { FTPBaseHandler } from "../../../FTPBase.Handler";
import { IFTPHandlerParams } from "../../../IFTPHandlerParams";
export default class UploadStdinToUssFileHandler extends FTPBaseHandler {
    processFTP(params: IFTPHandlerParams): Promise<void>;
}
