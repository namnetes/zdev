import { ICommandDefinition } from "@zowe/imperative";
export declare const UploadFileToDataSetDefinition: ICommandDefinition;
