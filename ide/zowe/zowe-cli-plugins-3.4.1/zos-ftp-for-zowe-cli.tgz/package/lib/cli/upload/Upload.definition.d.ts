import { ICommandDefinition } from "@zowe/imperative";
declare const UploadDefinition: ICommandDefinition;
export = UploadDefinition;
