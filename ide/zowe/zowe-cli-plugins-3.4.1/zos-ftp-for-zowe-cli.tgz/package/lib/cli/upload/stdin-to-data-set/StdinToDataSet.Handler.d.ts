import { IFTPHandlerParams } from "../../../IFTPHandlerParams";
import { FTPBaseHandler } from "../../../FTPBase.Handler";
export default class UploadStdinToDataSetHandler extends FTPBaseHandler {
    processFTP(params: IFTPHandlerParams): Promise<void>;
}
