import { ICommandDefinition } from "@zowe/imperative";
export declare const UploadStdinToDataSetDefinition: ICommandDefinition;
