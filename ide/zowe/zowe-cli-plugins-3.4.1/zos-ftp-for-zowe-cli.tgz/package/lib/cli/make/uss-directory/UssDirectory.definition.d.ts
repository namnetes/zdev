import { ICommandDefinition } from "@zowe/imperative";
export declare const MakeUssDirectoryDefinition: ICommandDefinition;
