import { ICommandDefinition } from "@zowe/imperative";
declare const MakeDefinition: ICommandDefinition;
export = MakeDefinition;
