import { ICommandDefinition } from "@zowe/imperative";
export declare const DeleteJobDefinition: ICommandDefinition;
