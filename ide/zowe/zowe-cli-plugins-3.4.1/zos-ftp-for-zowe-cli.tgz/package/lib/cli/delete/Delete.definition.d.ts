import { ICommandDefinition } from "@zowe/imperative";
declare const DeleteDefinition: ICommandDefinition;
export = DeleteDefinition;
