import { ICommandDefinition } from "@zowe/imperative";
export declare const DeleteDataSetDefinition: ICommandDefinition;
