import { ICommandHandler, IHandlerParameters, Logger } from "@zowe/imperative";
import { IFTPHandlerParams } from "./IFTPHandlerParams";
/**
 * This class is used by the various zos-ftp handlers as the base class for their implementation.
 * All handlers within zos-ftp should extend this class.
 *
 */
export declare abstract class FTPBaseHandler implements ICommandHandler {
    /**
     * This will grab the zos-ftp profile and create a connection before calling the subclass
     *
     * @param commandParameters Command parameters sent by imperative.
     *
     */
    process(commandParameters: IHandlerParameters): Promise<void>;
    /**
     * This is called by the subclass handlers after creating a connection. Should
     * be used so that every class under files does not have to instantiate the session object.
     *
     * @param  additionalParameters Extended parameters built during the process method including connection
     *
     * @returns  The response from the  create data set api call.
     */
    abstract processFTP(additionalParameters: IFTPHandlerParams): Promise<void>;
    protected get log(): Logger;
}
