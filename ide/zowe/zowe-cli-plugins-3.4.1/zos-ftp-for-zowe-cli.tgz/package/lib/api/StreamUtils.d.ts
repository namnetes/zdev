/// <reference types="node" />
/// <reference types="node" />
import { Readable, Writable } from "stream";
import { IFTPProgressHandler } from "./doc/IFTPProgressHandler";
export declare class StreamUtils {
    /**
     * @param size - file size
     * @param stream - readable stream
     * @param progress - optional progress handler
     * @returns promise that resolves buffer when accomplished
     */
    static streamToBuffer(size: number, stream: Readable, progress?: IFTPProgressHandler): Promise<Buffer>;
    /**
     * Pipes the readable stream to the writable stream.
     *
     * @param estimatedSize - estimated file size
     * @param stremPromise - promise that will resolve to a readable stream
     * @param writable - writable stream
     * @param progress - optional progress handler
     * @returns promise that resolves the downloaded bytes when accomplished
     */
    static streamToStream(size: number, stream: Readable, writable: Writable, progress?: IFTPProgressHandler): Promise<number>;
}
