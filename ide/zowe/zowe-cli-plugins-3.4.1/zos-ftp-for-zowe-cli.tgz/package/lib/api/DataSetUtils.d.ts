/// <reference types="node" />
import { IAllocateDataSetOption, IDatasetEntry, IDatasetMemberEntry, IDownloadDataSetOption, IUploadDataSetOption } from "./doc/DataSetInterface";
import { ZosAccessor } from "zos-node-accessor";
export declare class DataSetUtils {
    /**
     * Lists datasets with the specified dataset name pattern.
     *
     * @param connection - zos-node-accessor connection
     * @param pattern - dataset name pattern
     * @returns dataset entries
     */
    static listDataSets(connection: ZosAccessor, pattern: string): Promise<IDatasetEntry[]>;
    /**
     * Lists members of PDS dataset of the specified dataset name.
     *
     * @param connection - zos-node-accessor connection
     * @param dsn - fully-qualified dataset name without quotes
     * @returns member entries
     */
    static listMembers(connection: ZosAccessor, dsn: string): Promise<IDatasetMemberEntry[]>;
    /**
     * Delets the dataset of the specified dataset name.
     *
     * @param connection - zos-node-accessor connection
     * @param dsn - fully-qualified dataset name without quotes
     */
    static deleteDataSet(connection: ZosAccessor, dsn: string): Promise<void>;
    /**
     * Renames the dataset.
     *
     * @param connection - zos-node-accessor connection
     * @param oldDsn - old fully-qualified dataset name without quotes
     * @param newDsn - new fully-qualified dataset name without quotes
     */
    static renameDataSet(connection: ZosAccessor, oldDsn: string, newDsn: string): Promise<void>;
    /**
     * Downloads the dataset. The contents will saved in local file, if localFile is provided in option. Otherwise, the contents
     * will be returned in Buffer.
     *
     * @param connection - zos-node-accessor connection
     * @param dsn - fully-qualified dataset name without quotes
     * @param option - download option
     * @returns dataset contents in Buffer, if localFile is not provided in option. Otherwise, undefined will be returned.
     */
    static downloadDataSet(connection: ZosAccessor, dsn: string, option: IDownloadDataSetOption): Promise<Buffer>;
    /**
     * Uploads the content to the specified dataset.
     *
     * @param connection - zos-node-accessor connection
     * @param dsn - fully-qualified dataset name without quotes
     * @param option - upload option
     */
    static uploadDataSet(connection: ZosAccessor, dsn: string, option: IUploadDataSetOption): Promise<void>;
    /**
     * Allocate dataset.
     *
     * @param connection - zos-node-accessor connection
     * @param dsn - fully-qualified dataset name without quotes
     * @param option - Allocate option
     */
    static allocateDataSet(connection: ZosAccessor, dsn: string, option: IAllocateDataSetOption): Promise<void>;
    private static get log();
}
