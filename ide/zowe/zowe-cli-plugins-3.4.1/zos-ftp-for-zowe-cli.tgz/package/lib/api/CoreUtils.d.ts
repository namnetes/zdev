/// <reference types="node" />
/// <reference types="node" />
import { ICommandProfileTypeConfiguration, Logger } from "@zowe/imperative";
import * as stream from "stream";
import { TransferMode } from "zos-node-accessor";
export declare class CoreUtils {
    /**
     * Sleep for a number of milliseconds
     * @param ms - how many miliseconds to sleep or (at least)
     * @returns promise that resolves when the sleep is complete (or after, not guaranteed)
     */
    static sleep(ms: number): Promise<unknown>;
    /**
     * Make sure newlines in a string have carriage returns
     * This is required to prevent errors when transferring
     * in ascii mode
     * @param  original - the original string which you would like to ensure has \r before \n
     * @returns a string where every \n has a \r before it
     */
    static addCarriageReturns(original: string): string;
    /**
     * Read the complete contents of stdin
     * @param stream - A custom stream to read stdin data from
     * @returns contents piped in to stdin
     */
    static readStdin(stream?: stream.Readable): Promise<Buffer>;
    static getProfileSchema(): Promise<ICommandProfileTypeConfiguration[]>;
    protected static get log(): Logger;
    static getBinaryTransferModeOrDefault(isBinary: boolean, rdw?: boolean): TransferMode;
}
