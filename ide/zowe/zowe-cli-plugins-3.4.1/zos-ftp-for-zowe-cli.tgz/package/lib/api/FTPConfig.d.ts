import { ZosAccessor } from "zos-node-accessor";
import { ICommandArguments, ICommandOptionDefinition, IHandlerParameters } from "@zowe/imperative";
import { IConnectionOption } from "./doc";
export declare class FTPConfig {
    static OPTION_HOST: ICommandOptionDefinition;
    static OPTION_PORT: ICommandOptionDefinition;
    static OPTION_USER: ICommandOptionDefinition;
    static OPTION_PASSWORD: ICommandOptionDefinition;
    static OPTION_SECURE_FTP: ICommandOptionDefinition;
    static OPTION_REJECT_UNAUTHORIZED: ICommandOptionDefinition;
    static OPTION_SERVER_NAME: ICommandOptionDefinition;
    static OPTION_CONNECTION_TIMEOUT: ICommandOptionDefinition;
    static OPTION_ENCODING: ICommandOptionDefinition;
    /**
     * Shared options used by all FTP commands
     */
    static FTP_CONNECTION_OPTIONS: ICommandOptionDefinition[];
    /**
     * Convert a profile into a config object used to connect to
     * zos-node-accessor
     * @param arguments - the arguments passed by the user
     * @param doPrompting - Whether to prompt for missing arguments (defaults to true)
     * @param {IHandlerParameters} handlerParams - The command parameters object for daemon mode prompting
     * @returns  the connection to zos-node-accessor's APIs
     */
    static connectFromArguments(args: ICommandArguments, doPrompting?: boolean, handlerParams?: IHandlerParameters): Promise<ZosAccessor>;
    /**
     * Convert a profile into a config object used to connect to
     * zos-node-accessor
     * @param arguments - the profile created by the user
     * @returns the config object for zos-node-accessor's ftp connection
     */
    static createConfigFromArguments(args: Partial<ICommandArguments>): IConnectionOption;
    /**
     * Determine whether the user specified any TLS connection options
     * @param args - the profile loaded from the user
     * @returns true if the user has specified any secure connection options
     */
    private static profileHasSecureOptions;
}
