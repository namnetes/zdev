import { IDownloadSpoolContentParms, IGetSpoolDownloadFilePath, IGetSpoolFileOption, IJob, IJobStatus, IListJobOption, ISpoolFile } from "./doc/JobInterface";
import { ZosAccessor } from "zos-node-accessor";
export declare class JobUtils {
    /**
     * Lists jobs with the job name prefix.
     *
     * @param connection - zos-node-accessor connection
     * @param prefix - job name prefix
     * @param option - list job option
     * @returns job entries
     */
    static listJobs(connection: ZosAccessor, prefix: string, option?: IListJobOption): Promise<IJob[]>;
    /**
     * Deletes the job with the job id.
     *
     * @param connection - zos-node-accessor connection
     * @param jobId - job id
     */
    static deleteJob(connection: ZosAccessor, jobId: string): Promise<void>;
    /**
     * Return the job spool files content of the specified job id and spool file id.
     *
     * @param connection - zos-node-accessor connection
     * @param option - option
     * @returns spool file content
     */
    static getSpoolFileContent(connection: ZosAccessor, option: IGetSpoolFileOption): Promise<string>;
    /**
     * Return the all job spool files content of the specified job id.
     *
     * @param connection - zos-node-accessor connection
     * @param jobId - job ID
     * @returns spool files with content
     */
    static getSpoolFiles(connection: ZosAccessor, jobId: string): Promise<ISpoolFile[]>;
    /**
     * Submits job with the specified JCL.
     *
     * @param connection - zos-node-accessor connection
     * @param jcl - jcl
     * @returns job id
     */
    static submitJob(connection: ZosAccessor, jcl: string): Promise<string>;
    /**
     * Submits job with the specified JCL dataset.
     *
     * @param connection - zos-node-accessor connection
     * @param dsn - fully-qualified JCL dataset name without quotes
     * @returns job id
     */
    static submitJobFromDataset(connection: ZosAccessor, dsn: string): Promise<string>;
    /**
     * Identify a job by job ID
     * Warning: slow since it lists all jobs
     * @param  jobId - the job ID of the job you want to identify -
     *                         note: you can't use the abbreviated version like j123. it must be the full job ID
     * @param connection - connection to zos-node-accessor
     */
    static findJobByID(connection: ZosAccessor, jobId: string): Promise<IJobStatus>;
    static downloadSpoolContent(connection: ZosAccessor, parms: IDownloadSpoolContentParms): Promise<void>;
    static getSpoolDownloadFilePath(parms: IGetSpoolDownloadFilePath): string;
    private static get log();
}
