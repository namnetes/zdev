export interface IFTPProgressHandler {
    /**
     * Starts a FTP task with the total work size.
     *
     * @param total - total work size
     */
    start(total: number): void;
    /**
     * Updates how much work is performed, so that the class implementing this interface can update progress bar for example.
     *
     * @param work - how much work is performed
     */
    worked(work: number): void;
    /**
     * The FTP task ends, either all work is completed or any error happens.
     */
    end(): void;
}
