import { IProfile } from "@zowe/imperative";
import { ConnectionOption } from "zos-node-accessor/lib/interfaces/ConnectionOption";
export interface IConnectionOption extends ConnectionOption {
}
/**
 * Typescript representation of a loaded zos-ftp profile
 */
export interface IZosFTPProfile extends IProfile {
    user: string;
    password: string;
    host: string;
    port: number;
    /**
     *  Set to true for both control and data connection encryption,
     *  'control' for control connection encryption only, or 'implicit' for
     *  implicitly encrypted control connection (this mode is deprecated in modern times,
     *  but usually uses port 990)
     */
    secureFtp?: boolean;
    /**
     * TLS connection options that can be specified by the user in their profile
     */
    rejectUnauthorized?: boolean;
    /**
     * certificate authority for your secure connection
     */
    serverName?: string;
    jobCardFile?: string;
    /**
     * The encoding for download and upload of z/OS data set
     */
    encoding?: string;
}
