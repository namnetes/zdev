import { CreateDataSetTypeEnum, ICreateDataSetOptions, IZosFilesResponse } from "@zowe/cli";
import { AbstractTemplatedJCL } from "./AbstractTemplatedJCL";
import { ZosAccessor } from "zos-node-accessor";
export declare class CreateDataset extends AbstractTemplatedJCL {
    /**
     * Create a data set
     * @param connection                 - zos-node-accessor connection
     * @param  cmdType               - The type of data set we are going to create
     * @param dataSetName                          - the name of the data set to create
     * @param  [options={}] - additional options for the creation of the data set
     */
    static create(connection: ZosAccessor, cmdType: CreateDataSetTypeEnum, dataSetName: string, jobCardFile: string, options?: Partial<ICreateDataSetOptions>): Promise<IZosFilesResponse>;
    DEFAULT_TEMPLATE: string;
    private createViaFTP;
}
