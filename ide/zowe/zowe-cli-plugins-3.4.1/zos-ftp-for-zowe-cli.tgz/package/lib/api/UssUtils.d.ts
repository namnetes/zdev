/// <reference types="node" />
import { IHandlerResponseConsoleApi } from "@zowe/imperative";
import { IDeleteFileOption, IDownloadFileOption, IUSSEntry, IUploadFileOption } from "./doc/UssInterface";
import { ZosAccessor } from "zos-node-accessor";
export declare class UssUtils {
    /**
     * Lists files under the specified directory.
     *
     * @param connection - zos-node-accessor connection
     * @param directory - directory to list
     * @returns file entries
     */
    static listFiles(connection: ZosAccessor, directory: string): Promise<IUSSEntry[]>;
    /**
     * Makes directory.
     *
     * @param connection - zos-node-accessor connection
     * @param directory - directory to make
     */
    static makeDirectory(connection: ZosAccessor, directory: string): Promise<void>;
    /**
     * Renames file or directory.
     *
     * @param connection - zos-node-accessor connection
     * @param oldNanme - old name of file or directory
     * @param newName - new name of file or directory
     */
    static renameFile(connection: ZosAccessor, oldNanme: string, newName: string): Promise<void>;
    /**
     * Deletes file or directory.
     *
     * @param connection - zos-node-accessor connection
     * @param fileOrDir - file or directory
     * @param option - delete file option
     */
    static deleteFile(connection: ZosAccessor, fileOrDir: string, option?: IDeleteFileOption): Promise<void>;
    /**
     * Downloads file.
     *
     * @param connection - zos-node-accessor connection
     * @param ussFile - file path name
     * @param option - download option
     * @returns promise to return buffer when accomplished. If `localFile` is specified, return undefined.
     */
    static downloadFile(connection: ZosAccessor, ussFile: string, option: IDownloadFileOption): Promise<Buffer>;
    /**
     * Uploads file.
     *
     * @param connection - zos-node-accessor connection
     * @param ussFile - file path name
     * @param option - upload option
     */
    static uploadFile(connection: ZosAccessor, ussFile: string, option: IUploadFileOption): Promise<void>;
    /**
     * Try to make sure a unix path conforms to what ftp expects
     * Includes fixing paths that are messed up by git for windows tools
     * like turning paths /u/users into U:/Users
     * @param path - the path to normalize
     * @returns the normalized path
     */
    static normalizeUnixPath(path: string): string;
    static deleteDirectory(connection: ZosAccessor, dir: string, response?: IHandlerResponseConsoleApi): Promise<void>;
    static checkAbsoluteFilePath(filePath: string): string;
    private static get log();
}
