import { Logger } from "@zowe/imperative";
export declare abstract class AbstractTemplatedJCL {
    /**
     * Default job template for submitting your JCL
     */
    abstract readonly DEFAULT_TEMPLATE: string;
    /**
     *
     * @param jobCardFile - file containing a job card which will be prepended to the job
     * @param  substitutionValues -
     * @param  templateFile - override the default JCL template with a file
     */
    getJcl(jobCardFile: string, substitutionValues: {
        [key: string]: string;
    }, templateFile?: string): string;
    protected get log(): Logger;
}
