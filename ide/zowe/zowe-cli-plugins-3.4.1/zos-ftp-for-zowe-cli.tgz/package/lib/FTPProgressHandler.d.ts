import { IHandlerProgressApi } from "@zowe/imperative";
import { IFTPProgressHandler } from "./api";
export declare class FTPProgressHandler implements IFTPProgressHandler {
    private progress;
    private estimated;
    private task;
    private processed;
    private total;
    private statusMessage;
    constructor(progress: IHandlerProgressApi, estimated?: boolean);
    start(total: number): void;
    worked(work: number): void;
    end(): void;
}
