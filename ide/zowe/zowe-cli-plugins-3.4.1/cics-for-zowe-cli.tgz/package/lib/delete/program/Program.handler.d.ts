/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { ICMCIApiResponse } from "@zowe/cics-for-zowe-sdk";
import { AbstractSession, IHandlerParameters } from "@zowe/imperative";
import { CicsBaseHandler } from "../../CicsBaseHandler";
/**
 * Command handler for deleting CICS programs via CMCI
 * @export
 * @class ProgramHandler
 * @implements {ICommandHandler}
 */
export default class ProgramHandler extends CicsBaseHandler {
    processWithSession(params: IHandlerParameters, session: AbstractSession): Promise<ICMCIApiResponse>;
}
