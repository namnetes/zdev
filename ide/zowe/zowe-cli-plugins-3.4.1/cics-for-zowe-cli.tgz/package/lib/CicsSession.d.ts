/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { ICommandArguments, ICommandOptionDefinition, IHandlerParameters, IProfile, Session } from "@zowe/imperative";
/**
 * Utility Methods for Zowe
 * @export
 */
export declare class CicsSession {
    static CICS_CONNECTION_OPTION_GROUP: string;
    /**
     * Option used in profile creation and commands for hostname for CICS
     */
    static CICS_OPTION_HOST: ICommandOptionDefinition;
    /**
     * Option used in profile creation and commands for port for CICS
     */
    static CICS_OPTION_PORT: ICommandOptionDefinition;
    /**
     * Option used in profile creation and commands for username / ID  for CICS
     */
    static CICS_OPTION_USER: ICommandOptionDefinition;
    /**
     * Option used in profile creation and commands for password/passphrase for CICS
     */
    static CICS_OPTION_PASSWORD: ICommandOptionDefinition;
    /**
     * Option used in profile creation and commands for rejectUnauthorized setting for connecting to FMP
     */
    static CICS_OPTION_REJECT_UNAUTHORIZED: ICommandOptionDefinition;
    /**
     * Option used in profile creation and commands for protocol for CMCI
     */
    static CICS_OPTION_PROTOCOL: ICommandOptionDefinition;
    /**
     * Options related to connecting to CICS
     * These options can be filled in if the user creates a profile
     */
    static CICS_CONNECTION_OPTIONS: ICommandOptionDefinition[];
    /**
     * Given a CICS profile, create a REST Client Session.
     * @static
     * @param {IProfile} profile - The CICS profile contents
     * @returns {Session} - A session for usage in the CMCI REST Client
     */
    static createBasicCicsSession(profile: IProfile): Session;
    /**
     * Given command line arguments, create a REST Client Session.
     * @static
     * @param {IProfile} args - The arguments specified by the user
     * @returns {Session} - A session for usage in the CMCI REST Client
     */
    static createBasicCicsSessionFromArguments(args: ICommandArguments): Session;
    /**
     * Given command line arguments, create a REST Client Session.
     * @static
     * @param {IProfile} args - The arguments specified by the user
     * @param {boolean} doPrompting - Whether to prompt for missing arguments (defaults to true)
     * @param {IHandlerParameters} handlerParams - The command parameters object for Daemon mode prompting
     * @returns {Session} - A session for usage in the CMCI REST Client
     */
    static createSessCfgFromArgs(args: ICommandArguments, doPrompting?: boolean, handlerParams?: IHandlerParameters): Promise<Session>;
    private static get log();
}
