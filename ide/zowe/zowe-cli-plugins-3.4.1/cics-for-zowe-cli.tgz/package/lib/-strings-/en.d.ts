/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
declare const _default: {
    ADDTOLIST: {
        SUMMARY: string;
        DESCRIPTION: string;
        RESOURCES: {
            CSDGROUP: {
                DESCRIPTION: string;
                POSITIONALS: {
                    NAME: string;
                    CSDLIST: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
        };
    };
    DEFINE: {
        SUMMARY: string;
        DESCRIPTION: string;
        RESOURCES: {
            PROGRAM: {
                DESCRIPTION: string;
                POSITIONALS: {
                    PROGRAMNAME: string;
                    CSDGROUP: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
            TRANSACTION: {
                DESCRIPTION: string;
                POSITIONALS: {
                    TRANSACTIONNAME: string;
                    PROGRAMNAME: string;
                    CSDGROUP: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
            URIMAP: {
                DESCRIPTION: {
                    SERVER: string;
                    CLIENT: string;
                    PIPELINE: string;
                };
                POSITIONALS: {
                    URIMAPNAME: string;
                    CSDGROUP: string;
                };
                OPTIONS: {
                    URIMAPHOST: string;
                    URIMAPPATH: string;
                    URIMAPSCHEME: string;
                    REGIONNAME: string;
                    CICSPLEX: string;
                    PROGRAMNAME: string;
                    PIPELINENAME: string;
                    CERTIFICATE: string;
                    AUTHENTICATE: string;
                    DESCRIPTION: string;
                    TRANSACTIONNAME: string;
                    WEBSERVICENAME: string;
                    ENABLE: string;
                    TCPIPSERVICE: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    SERVER: {
                        EX1: string;
                    };
                    CLIENT: {
                        EX1: string;
                    };
                    PIPELINE: {
                        EX1: string;
                    };
                };
            };
            WEBSERVICE: {
                DESCRIPTION: string;
                POSITIONALS: {
                    WEBSERVICENAME: string;
                    CSDGROUP: string;
                };
                OPTIONS: {
                    PIPELINENAME: string;
                    WSBIND: string;
                    DESCRIPTION: string;
                    VALIDATION: string;
                    WSDLFILE: string;
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
            BUNDLE: {
                DESCRIPTION: string;
                POSITIONALS: {
                    BUNDLENAME: string;
                    CSDGROUP: string;
                    BUNDLEDIR: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
        };
    };
    DELETE: {
        SUMMARY: string;
        DESCRIPTION: string;
        RESOURCES: {
            PROGRAM: {
                DESCRIPTION: string;
                POSITIONALS: {
                    PROGRAMNAME: string;
                    CSDGROUP: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
            TRANSACTION: {
                DESCRIPTION: string;
                POSITIONALS: {
                    TRANSACTIONNAME: string;
                    CSDGROUP: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
            URIMAP: {
                DESCRIPTION: string;
                POSITIONALS: {
                    URIMAPNAME: string;
                    CSDGROUP: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
            WEBSERVICE: {
                DESCRIPTION: string;
                POSITIONALS: {
                    WEBSERVICENAME: string;
                    CSDGROUP: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
        };
    };
    DISABLE: {
        SUMMARY: string;
        DESCRIPTION: string;
        RESOURCES: {
            URIMAP: {
                DESCRIPTION: string;
                POSITIONALS: {
                    URIMAPNAME: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
        };
    };
    DISCARD: {
        SUMMARY: string;
        DESCRIPTION: string;
        RESOURCES: {
            PROGRAM: {
                DESCRIPTION: string;
                POSITIONALS: {
                    PROGRAMNAME: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
            TRANSACTION: {
                DESCRIPTION: string;
                POSITIONALS: {
                    TRANSACTIONNAME: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
            URIMAP: {
                DESCRIPTION: string;
                POSITIONALS: {
                    URIMAPNAME: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
        };
    };
    ENABLE: {
        SUMMARY: string;
        DESCRIPTION: string;
        RESOURCES: {
            URIMAP: {
                DESCRIPTION: string;
                POSITIONALS: {
                    URIMAPNAME: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
        };
    };
    GET: {
        SUMMARY: string;
        DESCRIPTION: string;
        RESOURCES: {
            RESOURCE: {
                DESCRIPTION: string;
                POSITIONALS: {
                    RESOURCENAME: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                    CRITERIA: string;
                    PARAMETER: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                    EX2: string;
                    EX3: string;
                    EX4: string;
                    EX5: string;
                    EX6: string;
                    EX7: string;
                    EX8: string;
                    EX9: string;
                };
            };
        };
    };
    INSTALL: {
        SUMMARY: string;
        DESCRIPTION: string;
        RESOURCES: {
            PROGRAM: {
                DESCRIPTION: string;
                POSITIONALS: {
                    PROGRAMNAME: string;
                    CSDGROUP: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
            TRANSACTION: {
                DESCRIPTION: string;
                POSITIONALS: {
                    TRANSACTIONNAME: string;
                    CSDGROUP: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
            URIMAP: {
                DESCRIPTION: string;
                POSITIONALS: {
                    URIMAPNAME: string;
                    CSDGROUP: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
        };
    };
    REFRESH: {
        SUMMARY: string;
        DESCRIPTION: string;
        RESOURCES: {
            PROGRAM: {
                DESCRIPTION: string;
                POSITIONALS: {
                    PROGRAMNAME: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    DEFINE_EXAMPLE_ONE: string;
                };
            };
        };
    };
    REMOVEFROMLIST: {
        SUMMARY: string;
        DESCRIPTION: string;
        RESOURCES: {
            CSDGROUP: {
                DESCRIPTION: string;
                POSITIONALS: {
                    NAME: string;
                    CSDLIST: string;
                };
                OPTIONS: {
                    REGIONNAME: string;
                    CICSPLEX: string;
                };
                MESSAGES: {
                    SUCCESS: string;
                };
                EXAMPLES: {
                    EX1: string;
                };
            };
        };
    };
};
export default _default;
