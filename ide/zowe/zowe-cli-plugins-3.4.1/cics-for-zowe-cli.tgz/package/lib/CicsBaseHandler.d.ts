/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { ICMCIApiResponse } from "@zowe/cics-for-zowe-sdk";
import { AbstractSession, ICommandHandler, IHandlerParameters } from "@zowe/imperative";
/**
 * This class is used by the various cics handlers as the base class for their implementation.
 * All handlers should extend this class whenever possible
 */
export declare abstract class CicsBaseHandler implements ICommandHandler {
    /**
     * This will grab the cics profile and create a session before calling the subclass
     * {@link CicsBaseHandler#processWithSession} method.
     *
     * @param {IHandlerParameters} commandParameters Command parameters sent by imperative.
     *
     * @returns {Promise<void>}
     */
    process(commandParameters: IHandlerParameters): Promise<void>;
    /**
     * This is called by the {@link CicsBaseHandler#process} after it creates a session. Should
     * be used so that every class does not have to instantiate the session object.
     *
     * @param {IHandlerParameters} commandParameters Command parameters sent to the handler.
     * @param {AbstractSession} session The session object generated from the cics profile.
     *
     * @returns {Promise<ICMCIApiResponse>} The response from the underlying cics api call.
     */
    abstract processWithSession(commandParameters: IHandlerParameters, session: AbstractSession): Promise<ICMCIApiResponse>;
}
